package com.example.realga93.flycam;

import android.util.Log;

import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Created by realga93 on 4/20/2016.
 */
public class FlightLoop extends Thread {

    private volatile boolean stop = false;

    public void run() {

        while(!stop) {
            String forward = Globals.getForward();
            String left = Globals.getLeft();
            String backward = Globals.getBackward();
            String right = Globals.getRight();


            String up = Globals.getUp();
            String clockwise = Globals.getClockwise();
            String down = Globals.getDown();
            String counterClockwise = Globals.getCounterclockwise();

            String auto = Globals.getAuto();
            String camUp = Globals.getCamUp();
            String camDown = Globals.getCamDown();
            String power = Globals.getPower();

            String command = forward + left + backward + right + up + clockwise + down + counterClockwise + auto + camUp + camDown + power;

            Log.d("Command", command);

            //Globals.setAllOff();

            try {
                DataOutputStream dataOutputStream = null;

                try {
                    dataOutputStream = new DataOutputStream(Globals.getSocket().getOutputStream());
                    dataOutputStream.writeBytes(command + "/n");

                }catch (IOException e){
                    e.printStackTrace();
                }

                Thread.sleep(500);

            }catch (InterruptedException e){
                e.printStackTrace();
            }
            if (Globals.getSocket().isClosed()){
                this.stop();
            }
        }
    }

    public synchronized void requestStop() {
        stop = true;
    }
}
