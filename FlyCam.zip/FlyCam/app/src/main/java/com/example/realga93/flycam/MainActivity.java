package com.example.realga93.flycam;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    /*private static final String TAG = "xkcdMainActivity";
    private static final String explination_url = "http://www.explainxkcd.com/wiki/index.php/";
    private static final String xkcd_mobile_url = "http://m.xkcd.com/";
    private int current_comic;/*the current comic being displayed*/
    //private int max_comic; /*the most recent comic, and therefore the maximum comic to serve*/
    //private ContentResolver resolver;
    //private ImageViewTouch imageViewTouch;
    //private ProgressBar loader;

    private int mode_number;

    public MainActivity() {
        mode_number = 0;
        //current_comic = -1;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final Button modeButton = (Button) findViewById(R.id.btn_mode);
        modeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mode_number == 0) {
                    modeButton.setText("Manual");
                    adjustButtons(false);
                    mode_number = 1;
                    Globals.setAuto("N");
                } else if (mode_number == 1) {
                    modeButton.setText("Auto");
                    adjustButtons(true);
                    mode_number = 0;
                    Globals.setAuto("Y");
                }
            }
        });

        Button rightButton = (Button) findViewById(R.id.btn_right);
        rightButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setRight("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setRight("N");
                        return true;
                }
                return false;
            }
        });

        Button forwardButton = (Button) findViewById(R.id.btn_forward);
        forwardButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setForward("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setForward("N");
                        return true;
                }
                return false;
            }
        });

        Button leftButton = (Button) findViewById(R.id.btn_left);
        leftButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setLeft("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setLeft("N");
                        return true;
                }
                return false;
            }
        });

        Button backwardButton = (Button) findViewById(R.id.btn_backward);
        backwardButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setBackward("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setBackward("N");
                        return true;
                }
                return false;
            }
        });

        Button clockwiseButton = (Button) findViewById(R.id.btn_clockwise);
        clockwiseButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setClockwise("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setClockwise("N");
                        return true;
                }
                return false;
            }
        });

        Button upButton = (Button) findViewById(R.id.btn_up);
        upButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setUp("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setUp("N");
                        return true;
                }
                return false;
            }
        });

        Button counterclockwiseButton = (Button) findViewById(R.id.btn_counterclockwise);
        counterclockwiseButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setCounterclockwise("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setCounterclockwise("N");
                        return true;
                }
                return false;
            }
        });

        Button downButton = (Button) findViewById(R.id.btn_down);
        downButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Globals.setDown("Y");
                        return true;

                    case MotionEvent.ACTION_UP:
                        Globals.setDown("N");
                        return true;
                }
                return false;
            }
        });

        Button powerButton = (Button) findViewById(R.id.btn_power);
        powerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (Globals.getPower().equals("N")){Globals.setPower("Y");}

                else {Globals.setPower("N");}

            }
        });

        final FlightLoop flightLoop = new FlightLoop();

        Button connectButton = (Button)findViewById(R.id.btn_connect);
        connectButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                try{

                    int port = 2616;
                    String ipAddress = "192.168.43.30";
                    //InetAddress ipAddress = new InetAddress();
                    Globals.setSocket(new Socket(ipAddress, port));

                }catch(Exception e){
                    Log.d("MainActivity", "Socket connection Failed");
                }

                Globals.setSending(true);
                flightLoop.start();
            }
        });

        Button recordButton = (Button)findViewById(R.id.btn_rec);
        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Globals.getGoproReady() && !Globals.getRecord()){
                    //startRecordFunction

                    Globals.setRecord(true);
                }
                else if (Globals.getRecord()){
                    Globals.setRecord(false);
                }
            }


        });

        /*resolver = getContentResolver();
        setContentView(R.layout.activity_main);

        imageViewTouch = (ImageViewTouch) findViewById(R.id.imageView);
        imageViewTouch.setDisplayType(ImageViewTouchBase.DisplayType.FIT_TO_SCREEN);

        loader = (ProgressBar) findViewById(R.id.LoadingSpinner);
        loader.setIndeterminate(true);
        loader.setVisibility(View.INVISIBLE);


        Log.i(TAG, String.valueOf(current_comic));

        new GetCurrentComic(this).execute();

        Button prev_button = (Button) findViewById(R.id.btn_prev);
        prev_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (current_comic > 0) {
                    current_comic--;
                    new SetComic(MainActivity.this).execute(current_comic);
                }
            }
        });

        Button next_button = (Button) findViewById(R.id.btn_next);
        next_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (current_comic < max_comic) {
                    current_comic++;
                    new SetComic(MainActivity.this).execute(current_comic);
                }
            }
        });

        Button alt_text_button = (Button) findViewById(R.id.btn_alt_text);
        alt_text_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetAltText(MainActivity.this).execute(current_comic);
            }
        });
        */
    }


    private void adjustButtons(boolean manualMode) {
        Button rightButton = (Button)findViewById(R.id.btn_right);
        Button forwardButton = (Button)findViewById(R.id.btn_forward);
        Button leftButton = (Button)findViewById(R.id.btn_left);
        Button backwardButton = (Button)findViewById(R.id.btn_backward);
        Button clockwiseButton = (Button)findViewById(R.id.btn_clockwise);
        Button upButton = (Button)findViewById(R.id.btn_up);
        Button counterclockwiseButton = (Button)findViewById(R.id.btn_counterclockwise);
        Button downButton = (Button)findViewById(R.id.btn_down);

        if (manualMode){
            rightButton.setVisibility(View.VISIBLE);
            forwardButton.setVisibility(View.VISIBLE);
            leftButton.setVisibility(View.VISIBLE);
            backwardButton.setVisibility(View.VISIBLE);
            clockwiseButton.setVisibility(View.VISIBLE);
            upButton.setVisibility(View.VISIBLE);
            counterclockwiseButton.setVisibility(View.VISIBLE);
            downButton.setVisibility(View.VISIBLE);


            //turn on button visability
        }
        else {
            rightButton.setVisibility(View.INVISIBLE);
            forwardButton.setVisibility(View.INVISIBLE);
            leftButton.setVisibility(View.INVISIBLE);
            backwardButton.setVisibility(View.INVISIBLE);
            clockwiseButton.setVisibility(View.INVISIBLE);
            upButton.setVisibility(View.INVISIBLE);
            counterclockwiseButton.setVisibility(View.INVISIBLE);
            downButton.setVisibility(View.INVISIBLE);

            //turn off button visability
        }
    }
    /*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_comic_label:
                final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
                dialog.setTitle(R.string.number_popup_title);
                final LayoutInflater inflater = getLayoutInflater();
                final View view = inflater.inflate(R.layout.layout_select_comic, null);
                dialog.setView(view);
                final EditText comic_field = (EditText) view.findViewById(R.id.comic_number_input);
                dialog.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if ((comic_field.getText() == null)
                                || comic_field.getText().toString().equals("")) {
                            return;
                        }
                        final int comic_num;
                        try {
                            comic_num = Integer.parseInt(comic_field.getText().toString());
                        } catch (NumberFormatException e) {
                            /*invalid number, do nothing*//*
                            Log.i(TAG, "Invalid number: " + comic_field.getText());
                            return;
                        }
                        if (comic_num > max_comic) {
                            Log.i(TAG, "comic number past current comic: " + comic_field.getText());
                            return;
                        }
                        new SetComic(MainActivity.this).execute(comic_num);
                    }
                });
                dialog.show();
                return true;
            case R.id.action_random_comic:
                final Random r = new Random();
                final int next_comic = r.nextInt(max_comic);
                new SetComic(MainActivity.this).execute(next_comic);
                return true;
            case R.id.action_todays_comic:
                new GetCurrentComic(this).execute();
                return true;
            case R.id.action_explination:
                final Intent browserExplination = new Intent(Intent.ACTION_VIEW, Uri.parse(explination_url + current_comic));
                startActivity(browserExplination);
                return true;
            case R.id.action_view_in_browser:
                final Intent browserComic = new Intent(Intent.ACTION_VIEW, Uri.parse(xkcd_mobile_url + current_comic));
                startActivity(browserComic);
                return true;
            case R.id.action_share_image: {
                final GlideBitmapDrawable drawable = (GlideBitmapDrawable) imageViewTouch.getDrawable();
                this.shareBitmap(drawable.getBitmap());
                return true;
            }
            case R.id.action_save_image: {

                /*TODO: make this part work with android 6.0 new permissions system*/
//                int permission = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
/*
                final Uri uri = Uri.parse("content://media/external/images/media");
                final String provider = "com.android.providers.media.MediaProvider";
                grantUriPermission(provider, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                grantUriPermission(provider, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                grantUriPermission(provider, uri, Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                final GlideBitmapDrawable drawable = (GlideBitmapDrawable) imageViewTouch.getDrawable();
                MediaStore.Images.Media.insertImage(resolver, drawable.getBitmap(), this.getTitle().toString(), null);
                return true;
            }
        }
        return false;
    }

    @SuppressLint("SetWorldReadable")
    private void shareBitmap(Bitmap bitmap) {
        /*puts the image in the cache so as not to litter the filesystem*//*
        try {
            File file = new File(this.getCacheDir(), UUID.randomUUID().toString() + ".png");
            FileOutputStream fOut = new FileOutputStream(file);
            Log.i(TAG, "sharing image");
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();
            file.setReadable(true, false);
            final Intent shareImageIntent = new Intent(android.content.Intent.ACTION_SEND);
            shareImageIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
            shareImageIntent.setType("image/png");
            Intent intentChooser = Intent.createChooser(shareImageIntent, "Share Comic Image");
            startActivity(intentChooser);
        } catch (Exception e) {
            Log.e(TAG, "error", e);
        }
    }


    public void setCurrent_comic_num(int current_comic) {
        this.current_comic = current_comic;
        Log.i(TAG, String.format("Set comic: %d", current_comic));
    }

    public void setMax_comic(int max_comic) {
        this.max_comic = max_comic;
    }


    public void setImageViewByURL(String url) {
        /*remove the old image*//*
        imageViewTouch.setImageBitmap(null);
        /*start loading*//*
        MainActivity.this.setLoading(true);
        Glide.with(this).load(url).listener(new RequestListener<String, GlideDrawable>() {
            @Override
            public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                /*reset the loader if we get an exception*//*
                MainActivity.this.setLoading(false);
                return false;
            }

            @Override
            public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                /*reset the loader when we set the image*//*
                MainActivity.this.setLoading(false);
                return false;
            }
        }).into(imageViewTouch);
    }

    public void setLoading(final Boolean loading) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (loading) {
                    loader.setVisibility(View.VISIBLE);
                } else {
                    loader.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    public int getCurrent_comic() {
        return current_comic;
    }
*/

}
