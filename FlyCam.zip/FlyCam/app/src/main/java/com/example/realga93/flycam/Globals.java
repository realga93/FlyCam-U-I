package com.example.realga93.flycam;

import java.net.Socket;

/**
 * Created by realga93 on 4/20/2016.
 */
public class Globals {
    private static Globals instance;

    public static Globals getInstance() {
        return Globals.instance;
    }

    private static Socket S = new Socket();

    public static Socket getSocket() {
        return S;
    }

    public static void setSocket(Socket socket){
        S = socket;
    }

    private static boolean sending = false;

    public static boolean getSending(){return sending;}

    public static void setSending(Boolean b){
        sending = b;
    }

    private static boolean goproReady = false;
    public static void setGoproReady(boolean b){goproReady = b;}
    public static boolean getGoproReady(){return goproReady;}

    private static boolean record = false;
    public static void setRecord(boolean b){record = b;}
    public static boolean getRecord(){return record;}

    private static String forward = "N";
    private static String left = "N";
    private static String backward = "N";
    private static String right = "N";
    private static String up = "N";
    private static String clockwise = "N";
    private static String down = "N";
    private static String counterclockwise = "N";
    private static String auto = "N";
    private static String power = "N";

    public static String getForward(){return forward;}
    public static void setForward(String F) {forward = F;}

    public static String getLeft(){return left;}
    public static void setLeft(String L){left = L;}

    public static String getBackward(){return backward;}
    public static void setBackward(String B){backward = B;}

    public static String getRight(){return right;}
    public static void setRight(String R){right = R;}

    public static String getUp(){return up;}
    public static void setUp(String U){up = U;}

    public static String getClockwise(){return clockwise;}
    public static void setClockwise(String C){clockwise = C;}

    public static String getDown(){return down;}
    public static void setDown(String D){down = D;}

    public static String getCounterclockwise(){return counterclockwise;}
    public static void setCounterclockwise(String C){counterclockwise = C;}

    public static String getAuto(){return auto;}
    public static void setAuto(String A){auto = A;}

    public static String getPower(){return power;}
    public static void setPower(String P){power = P;}

    public static void setAllOff(){
        forward = "N";
        left = "N";
        backward = "N";
        right = "N";
        up = "N";
        clockwise = "N";
        down = "N";
        counterclockwise = "N";
    }
}
